
$(document).ready(function() {
  
$('input').on('change', function() {
var inputCont = $('.cont').text();
var inputAttr = $('input').val();
var re = /.*\..*/gi;
var inputAttrCut = inputAttr.match(re)
    $('.cont').html(inputAttrCut);
  })

});
